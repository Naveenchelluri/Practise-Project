package com.example.leavemanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LeavemanagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
